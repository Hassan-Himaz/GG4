"""
Python package wrapper for the pybind11 extension module.

The compiled extension module is expected to be:
- GG4/brain_sim.*.pyd (Windows) or GG4/brain_sim.*.so (Linux)

The extension module defines:
- class Brain (bound from CSimulator)

Usage:
    from GG4 import Brain
    b = Brain(random_seed=0)
    b.next_state()          # uses zero input by default
    y = b.measure()
"""

from __future__ import annotations

from importlib.metadata import version as _pkg_version

# C++: PYBIND11_MODULE(brain_sim, m) { ... py::class_<CSimulator>(m, "Brain") ... }
# Python extension path: GG4.brain_sim
from .brain_sim import Brain  # type: ignore

__all__ = ["Brain"]

# Single source of truth: pyproject.toml [project].version
__version__ = _pkg_version("GG4")